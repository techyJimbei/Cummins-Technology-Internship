# FailSafe_Webcam_Dataset2 > 2024-07-18 7:40am
https://universe.roboflow.com/shrutis-workspace/failsafe_webcam_dataset2

Provided by a Roboflow user
License: CC BY 4.0

